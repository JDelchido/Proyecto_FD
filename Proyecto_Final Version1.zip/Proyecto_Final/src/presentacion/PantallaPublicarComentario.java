package presentacion;

import javax.swing.*;

public class PantallaPublicarComentario {
    private JTextField textField1;
    private JPanel panel1;
    private JTextField textField2;
    private JTextField textField3;
}
